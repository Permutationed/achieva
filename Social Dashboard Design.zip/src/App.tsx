import { useState } from 'react';
import { Home, ListTodo, User } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { BucketListSection } from './components/BucketListSection';
import { PersonalBucketList } from './components/PersonalBucketList';

export default function App() {
  const [activeTab, setActiveTab] = useState<'feed' | 'shared' | 'personal'>('feed');

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex flex-col">
      {/* Content */}
      <div className="flex-1 overflow-hidden pb-16 md:pb-0">
        {activeTab === 'feed' && <Dashboard />}
        {activeTab === 'shared' && <BucketListSection />}
        {activeTab === 'personal' && <PersonalBucketList />}
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
        <div className="flex items-center justify-around px-2 py-2">
          <button
            onClick={() => setActiveTab('feed')}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors flex-1 ${
              activeTab === 'feed'
                ? 'text-indigo-700'
                : 'text-gray-600'
            }`}
          >
            <Home className={`w-6 h-6 ${activeTab === 'feed' ? 'fill-indigo-700' : ''}`} />
            <span className="text-xs">Feed</span>
          </button>
          <button
            onClick={() => setActiveTab('shared')}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors flex-1 ${
              activeTab === 'shared'
                ? 'text-indigo-700'
                : 'text-gray-600'
            }`}
          >
            <ListTodo className={`w-6 h-6 ${activeTab === 'shared' ? 'fill-indigo-700' : ''}`} />
            <span className="text-xs">Shared</span>
          </button>
          <button
            onClick={() => setActiveTab('personal')}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors flex-1 ${
              activeTab === 'personal'
                ? 'text-indigo-700'
                : 'text-gray-600'
            }`}
          >
            <User className={`w-6 h-6 ${activeTab === 'personal' ? 'fill-indigo-700' : ''}`} />
            <span className="text-xs">Personal</span>
          </button>
        </div>
      </nav>

      {/* Desktop Top Navigation */}
      <nav className="hidden md:block bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-8">
            <div className="py-4">
              <h1 className="text-gray-900">BucketList</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setActiveTab('feed')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'feed'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Home className="w-5 h-5" />
                <span>Feed</span>
              </button>
              <button
                onClick={() => setActiveTab('shared')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'shared'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <ListTodo className="w-5 h-5" />
                <span>Shared Bucket Lists</span>
              </button>
              <button
                onClick={() => setActiveTab('personal')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === 'personal'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <User className="w-5 h-5" />
                <span>Personal Bucket List</span>
              </button>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}