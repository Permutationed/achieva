import { useState } from 'react';
import { Heart, MessageCircle, CheckCircle2 } from 'lucide-react';

interface Comment {
  id: string;
  user: string;
  userAvatar: string;
  text: string;
  timestamp: string;
}

interface FeedItemData {
  id: string;
  user: string;
  userAvatar: string;
  action: 'completed' | 'added' | 'progress';
  goal: string;
  description?: string;
  image?: string;
  timestamp: string;
  encouragementCount: number;
  comments: Comment[];
  category: string;
  isLiked: boolean;
}

interface FeedItemProps {
  item: FeedItemData;
  onAddComment: (feedId: string, comment: string) => void;
  onToggleLike: (feedId: string) => void;
}

export function FeedItem({ item, onAddComment, onToggleLike }: FeedItemProps) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      onAddComment(item.id, newComment);
      setNewComment('');
    }
  };

  const getActionText = () => {
    switch (item.action) {
      case 'completed':
        return 'completed a goal';
      case 'added':
        return 'added a new goal';
      case 'progress':
        return 'made progress on';
      default:
        return '';
    }
  };

  const getActionColor = () => {
    switch (item.action) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'added':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'progress':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="p-4 pb-2">
        <div className="flex items-start gap-2">
          <img
            src={item.userAvatar}
            alt={item.user}
            className="w-10 h-10 rounded-full object-cover border-2 border-gray-100"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-gray-900 text-sm">{item.user}</span>
              <span className="text-gray-500 text-sm">{getActionText()}</span>
              {item.action === 'completed' && (
                <CheckCircle2 className="w-4 h-4 text-green-500" />
              )}
            </div>
            <p className="text-gray-500 text-xs mt-0.5">{item.timestamp}</p>
          </div>
        </div>

        {/* Goal Content */}
        <div className="mt-3">
          <div className={`inline-block px-2 py-0.5 rounded-full text-xs border mb-2 ${getActionColor()}`}>
            {item.category}
          </div>
          <h3 className="text-gray-900 text-base mb-1">{item.goal}</h3>
          {item.description && (
            <p className="text-gray-600 text-sm line-clamp-2">{item.description}</p>
          )}
        </div>
      </div>

      {/* Image */}
      {item.image && (
        <div className="px-4 pb-3 flex justify-center">
          <img
            src={item.image}
            alt={item.goal}
            className="w-3/4 h-40 object-cover rounded-lg"
          />
        </div>
      )}

      {/* Actions */}
      <div className="px-4 py-2 border-t border-gray-100 flex items-center gap-4">
        <button
          onClick={() => onToggleLike(item.id)}
          className="flex items-center gap-1.5 text-gray-600 hover:text-pink-500 transition-colors group text-sm"
        >
          <Heart
            className={`w-4 h-4 ${item.isLiked ? 'fill-pink-500 text-pink-500' : 'group-hover:scale-110'} transition-transform`}
          />
          <span className={item.isLiked ? 'text-pink-500' : ''}>
            {item.encouragementCount}
          </span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 text-gray-600 hover:text-indigo-500 transition-colors text-sm"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{item.comments.length}</span>
        </button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="px-4 pb-4 pt-2 border-t border-gray-100 bg-gray-50">
          <div className="space-y-3 mb-3">
            {item.comments.map(comment => (
              <div key={comment.id} className="flex gap-2">
                <img
                  src={comment.userAvatar}
                  alt={comment.user}
                  className="w-7 h-7 rounded-full object-cover flex-shrink-0"
                />
                <div className="flex-1 bg-white rounded-lg px-3 py-2 border border-gray-100">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-gray-900 text-xs">{comment.user}</span>
                    <span className="text-gray-400 text-xs">{comment.timestamp}</span>
                  </div>
                  <p className="text-gray-700 text-xs">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Add Comment */}
          <form onSubmit={handleSubmitComment} className="flex gap-2">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop"
              alt="You"
              className="w-7 h-7 rounded-full object-cover flex-shrink-0"
            />
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add encouragement..."
              className="flex-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-xs"
            >
              Send
            </button>
          </form>
        </div>
      )}
    </div>
  );
}