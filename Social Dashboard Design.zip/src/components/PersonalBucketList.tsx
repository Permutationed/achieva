import { useState } from 'react';
import { Plus, CheckCircle2, Circle, Camera, Trash2, Sparkles, Folder, ArrowLeft } from 'lucide-react';
import { AddGoalModal } from './AddGoalModal';

interface Goal {
  id: string;
  title: string;
  category: string;
  completed: boolean;
  image?: string;
}

interface GoalFolder {
  id: string;
  name: string;
  activeGoals: Goal[];
  completedGoals: Goal[];
}

export function PersonalBucketList() {
  const [folders, setFolders] = useState<GoalFolder[]>([
    {
      id: '1',
      name: 'Freshman Year USC',
      activeGoals: [
        {
          id: '1-1',
          title: 'Join a club or organization',
          category: 'Social',
          completed: false,
        },
        {
          id: '1-2',
          title: 'Attend a football game',
          category: 'Experience',
          completed: false,
        },
      ],
      completedGoals: [
        {
          id: '1-3',
          title: 'Get a 3.5 GPA',
          category: 'Academic',
          completed: true,
          image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=400&h=300&fit=crop',
        },
      ],
    },
    {
      id: '2',
      name: 'Sophomore Year USC',
      activeGoals: [
        {
          id: '2-1',
          title: 'Get an internship',
          category: 'Career',
          completed: false,
        },
        {
          id: '2-2',
          title: 'Study abroad',
          category: 'Travel',
          completed: false,
        },
      ],
      completedGoals: [],
    },
    {
      id: '3',
      name: 'Junior Year USC',
      activeGoals: [
        {
          id: '3-1',
          title: 'Take a leadership role in club',
          category: 'Leadership',
          completed: false,
        },
      ],
      completedGoals: [],
    },
    {
      id: '4',
      name: '30 Before 30',
      activeGoals: [
        {
          id: '4-1',
          title: 'Run a marathon',
          category: 'Health',
          completed: false,
        },
        {
          id: '4-2',
          title: 'Learn to play guitar',
          category: 'Creative',
          completed: false,
        },
        {
          id: '4-3',
          title: 'Visit 10 countries',
          category: 'Travel',
          completed: false,
        },
      ],
      completedGoals: [
        {
          id: '4-4',
          title: 'Visit Japan',
          category: 'Travel',
          completed: true,
          image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=400&h=300&fit=crop',
        },
        {
          id: '4-5',
          title: 'Read 50 books',
          category: 'Learning',
          completed: true,
          image: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=400&h=300&fit=crop',
        },
      ],
    },
    {
      id: '5',
      name: 'Summer Goals in NYC',
      activeGoals: [
        {
          id: '5-1',
          title: 'Try every pizza place in Brooklyn',
          category: 'Food',
          completed: false,
        },
        {
          id: '5-2',
          title: 'See a Broadway show',
          category: 'Entertainment',
          completed: false,
        },
        {
          id: '5-3',
          title: 'Explore Central Park',
          category: 'Adventure',
          completed: false,
        },
      ],
      completedGoals: [
        {
          id: '5-4',
          title: 'Visit the Statue of Liberty',
          category: 'Travel',
          completed: true,
          image: 'https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?w=400&h=300&fit=crop',
        },
      ],
    },
  ]);
  
  const [selectedFolderId, setSelectedFolderId] = useState(folders[0].id);
  const [showAddModal, setShowAddModal] = useState(false);
  const [imageToAdd, setImageToAdd] = useState<{ goalId: string } | null>(null);
  const [showSidebar, setShowSidebar] = useState(true);

  const selectedFolder = folders.find(f => f.id === selectedFolderId) || folders[0];

  const handleSelectFolder = (folderId: string) => {
    setSelectedFolderId(folderId);
    setShowSidebar(false); // Hide sidebar on mobile when selecting
  };

  const handleBackToList = () => {
    setShowSidebar(true);
  };

  const handleToggleGoal = (goalId: string) => {
    setFolders(folders.map(folder => {
      if (folder.id !== selectedFolderId) return folder;
      
      // Check if goal is in active goals
      const activeGoal = folder.activeGoals.find(g => g.id === goalId);
      if (activeGoal) {
        return {
          ...folder,
          activeGoals: folder.activeGoals.filter(g => g.id !== goalId),
          completedGoals: [{ ...activeGoal, completed: true }, ...folder.completedGoals],
        };
      }
      
      // Check if goal is in completed goals
      const completedGoal = folder.completedGoals.find(g => g.id === goalId);
      if (completedGoal) {
        return {
          ...folder,
          completedGoals: folder.completedGoals.filter(g => g.id !== goalId),
          activeGoals: [...folder.activeGoals, { ...completedGoal, completed: false }],
        };
      }
      
      return folder;
    }));
  };

  const handleAddGoal = (title: string, category: string, description: string) => {
    const newGoal: Goal = {
      id: Date.now().toString(),
      title,
      category,
      completed: false,
    };
    
    setFolders(folders.map(folder => 
      folder.id === selectedFolderId 
        ? { ...folder, activeGoals: [...folder.activeGoals, newGoal] }
        : folder
    ));
    setShowAddModal(false);
  };

  const handleDeleteGoal = (goalId: string) => {
    setFolders(folders.map(folder => {
      if (folder.id !== selectedFolderId) return folder;
      
      return {
        ...folder,
        activeGoals: folder.activeGoals.filter(g => g.id !== goalId),
        completedGoals: folder.completedGoals.filter(g => g.id !== goalId),
      };
    }));
  };

  const handleAddPhoto = (goalId: string) => {
    setImageToAdd({ goalId });
    setTimeout(() => {
      setFolders(folders.map(folder => {
        if (folder.id !== selectedFolderId) return folder;
        
        return {
          ...folder,
          completedGoals: folder.completedGoals.map(g => 
            g.id === goalId 
              ? { ...g, image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop' }
              : g
          ),
        };
      }));
      setImageToAdd(null);
    }, 500);
  };

  return (
    <div className="h-[calc(100vh-73px)] flex bg-white overflow-hidden">
      {/* Sidebar */}
      <div className={`w-full md:w-80 border-r border-gray-200 flex flex-col bg-gray-50 ${showSidebar ? 'block' : 'hidden'} md:block`}>
        <div className="p-4 border-b border-gray-200 bg-white">
          <h2 className="text-gray-900 mb-1">My Lists</h2>
          <p className="text-gray-600 text-sm">Organize your goals</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-3">
          {folders.map(folder => {
            const totalActive = folder.activeGoals.length;
            const totalCompleted = folder.completedGoals.length;
            
            return (
              <button
                key={folder.id}
                onClick={() => handleSelectFolder(folder.id)}
                className={`w-full text-left p-3 rounded-lg mb-2 transition-all ${
                  selectedFolderId === folder.id
                    ? 'bg-indigo-100 border-2 border-indigo-200'
                    : 'bg-white border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    selectedFolderId === folder.id
                      ? 'bg-indigo-500'
                      : 'bg-gray-200'
                  }`}>
                    <Folder className={`w-5 h-5 ${
                      selectedFolderId === folder.id ? 'text-white' : 'text-gray-600'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className={`text-sm mb-1 ${
                      selectedFolderId === folder.id ? 'text-indigo-900' : 'text-gray-900'
                    }`}>
                      {folder.name}
                    </h3>
                    <p className="text-xs text-gray-500">
                      {totalActive} active · {totalCompleted} completed
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className={`flex-1 flex flex-col bg-gradient-to-br from-indigo-50/30 to-purple-50/30 ${showSidebar ? 'hidden' : 'block'} md:block`}>
        {/* Mobile back button */}
        <button
          onClick={handleBackToList}
          className="md:hidden flex items-center gap-2 px-4 py-3 bg-white border-b border-gray-200 text-gray-700"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to lists</span>
        </button>
        
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-4 md:px-8 py-4 md:py-6">
          <div className="mb-4">
            <h1 className="text-gray-900">{selectedFolder.name}</h1>
            <p className="text-gray-600 text-sm">Track your goals and dreams</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 px-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 hover:scale-[1.02] flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Goal
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-4 md:px-8 py-4 md:py-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 h-full">
            {/* Active Goals Section */}
            <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                <h2 className="text-gray-900">Active Goals</h2>
                <span className="text-gray-500">({selectedFolder.activeGoals.length})</span>
              </div>
              
              {selectedFolder.activeGoals.length === 0 ? (
                <div className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-8 text-center">
                  <Circle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No active goals yet. Add one to get started!</p>
                </div>
              ) : (
                <div className="space-y-3 flex-1 overflow-y-auto pr-2">
                  {selectedFolder.activeGoals.map(goal => (
                    <div
                      key={goal.id}
                      className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start gap-4">
                        <button
                          onClick={() => handleToggleGoal(goal.id)}
                          className="flex-shrink-0 mt-1 w-6 h-6 rounded-full border-2 border-gray-300 hover:border-indigo-500 hover:bg-indigo-50 transition-all"
                        >
                          <Circle className="w-full h-full text-transparent" />
                        </button>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-gray-900 mb-2">{goal.title}</h3>
                          <span className="inline-block px-3 py-1 rounded-full text-xs bg-indigo-100 text-indigo-700 border border-indigo-200">
                            {goal.category}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDeleteGoal(goal.id)}
                          className="flex-shrink-0 text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Completed Goals Section */}
            <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <h2 className="text-gray-900">Completed</h2>
                <span className="text-gray-500">({selectedFolder.completedGoals.length})</span>
              </div>
              
              {selectedFolder.completedGoals.length === 0 ? (
                <div className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No completed goals yet. Keep working on them!</p>
                </div>
              ) : (
                <div className="space-y-3 flex-1 overflow-y-auto pr-2">
                  {selectedFolder.completedGoals.map(goal => (
                    <div
                      key={goal.id}
                      className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start gap-4">
                        <button
                          onClick={() => handleToggleGoal(goal.id)}
                          className="flex-shrink-0 mt-1 w-6 h-6 rounded-full bg-green-500 border-2 border-green-500 hover:bg-green-600 transition-all flex items-center justify-center"
                        >
                          <CheckCircle2 className="w-5 h-5 text-white" />
                        </button>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-4 mb-3">
                            <div className="flex-1">
                              <h3 className="text-gray-900 mb-2">{goal.title}</h3>
                            </div>
                            
                            {/* Photo Section */}
                            {goal.image ? (
                              <img
                                src={goal.image}
                                alt={goal.title}
                                className="w-24 h-24 rounded-lg object-cover flex-shrink-0"
                              />
                            ) : (
                              <button 
                                onClick={() => handleAddPhoto(goal.id)}
                                disabled={imageToAdd?.goalId === goal.id}
                                className="flex-shrink-0 w-24 h-24 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center bg-gray-50 hover:border-indigo-300 hover:bg-indigo-50/30 transition-all disabled:opacity-50"
                              >
                                <Camera className="w-6 h-6 text-gray-400 mb-1" />
                                <span className="text-gray-400 text-xs">Add photo</span>
                              </button>
                            )}
                          </div>
                          <span className="inline-block px-3 py-1 rounded-full text-xs bg-green-100 text-green-700 border border-green-200">
                            {goal.category}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDeleteGoal(goal.id)}
                          className="flex-shrink-0 text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add Goal Modal */}
      {showAddModal && (
        <AddGoalModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddGoal}
        />
      )}
    </div>
  );
}