import { useState } from 'react';
import { Target, CheckCircle2, Users, Heart, MessageCircle, ThumbsUp, X } from 'lucide-react';
import { FeedItem } from './FeedItem';

type StatView = 'active' | 'completed' | 'friends' | 'encouraged' | null;

export function Dashboard() {
  const [feedData, setFeedData] = useState([
    {
      id: '1',
      user: 'Sarah Johnson',
      userAvatar: 'https://i.pravatar.cc/150?img=1',
      goal: 'Learn to play guitar',
      category: 'Creative',
      progress: 60,
      isLiked: false,
      encouragementCount: 10,
      comments: [
        {
          id: 'comment-1',
          user: 'Mike Chen',
          userAvatar: 'https://i.pravatar.cc/150?img=2',
          text: 'Great progress!',
          timestamp: '2 days ago'
        }
      ]
    },
    {
      id: '2',
      user: 'Emma Davis',
      userAvatar: 'https://i.pravatar.cc/150?img=3',
      goal: 'Run a marathon',
      category: 'Health',
      progress: 30,
      isLiked: true,
      encouragementCount: 5,
      comments: [
        {
          id: 'comment-2',
          user: 'Alex Thompson',
          userAvatar: 'https://i.pravatar.cc/150?img=4',
          text: 'Keep it going!',
          timestamp: '3 days ago'
        }
      ]
    },
    {
      id: '3',
      user: 'Lisa Wang',
      userAvatar: 'https://i.pravatar.cc/150?img=5',
      goal: 'Visit Japan',
      category: 'Travel',
      progress: 85,
      isLiked: false,
      encouragementCount: 20,
      comments: [
        {
          id: 'comment-3',
          user: 'James Wilson',
          userAvatar: 'https://i.pravatar.cc/150?img=6',
          text: 'Sounds amazing!',
          timestamp: '4 days ago'
        }
      ]
    }
  ]);
  
  const [selectedStatView, setSelectedStatView] = useState<StatView>(null);

  const handleAddComment = (itemId: string, comment: string) => {
    setFeedData(prevData =>
      prevData.map(item =>
        item.id === itemId
          ? {
              ...item,
              comments: [
                ...item.comments,
                {
                  id: `comment-${Date.now()}`,
                  user: 'You',
                  userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
                  text: comment,
                  timestamp: 'Just now'
                }
              ]
            }
          : item
      )
    );
  };

  const handleToggleLike = (itemId: string) => {
    setFeedData(prevData =>
      prevData.map(item =>
        item.id === itemId
          ? {
              ...item,
              isLiked: !item.isLiked,
              encouragementCount: item.isLiked
                ? item.encouragementCount - 1
                : item.encouragementCount + 1
            }
          : item
      )
    );
  };

  // Mock data for stat views
  const activeGoalsData = [
    { id: '1', title: 'Learn to play guitar', category: 'Creative', progress: 60 },
    { id: '2', title: 'Run a marathon', category: 'Health', progress: 30 },
    { id: '3', title: 'Visit Japan', category: 'Travel', progress: 85 },
    { id: '4', title: 'Read 50 books', category: 'Learning', progress: 42 },
    { id: '5', title: 'Start a business', category: 'Career', progress: 15 },
    { id: '6', title: 'Learn Spanish', category: 'Learning', progress: 55 },
    { id: '7', title: 'Master cooking', category: 'Creative', progress: 70 },
    { id: '8', title: 'Climb a mountain', category: 'Adventure', progress: 25 },
    { id: '9', title: 'Write a novel', category: 'Creative', progress: 38 },
    { id: '10', title: 'Learn photography', category: 'Creative', progress: 65 },
    { id: '11', title: 'Travel to 5 countries', category: 'Travel', progress: 40 },
    { id: '12', title: 'Get a certification', category: 'Career', progress: 80 },
  ];

  const completedGoalsData = [
    { id: '1', title: 'Graduate college', category: 'Academic', completedDate: 'May 2024' },
    { id: '2', title: 'Visit Paris', category: 'Travel', completedDate: 'April 2024' },
    { id: '3', title: 'Run a 5K', category: 'Health', completedDate: 'March 2024' },
    { id: '4', title: 'Learn to cook Italian food', category: 'Creative', completedDate: 'February 2024' },
    { id: '5', title: 'Read 20 books', category: 'Learning', completedDate: 'January 2024' },
    { id: '6', title: 'Get promoted', category: 'Career', completedDate: 'December 2023' },
    { id: '7', title: 'Run 100 miles', category: 'Health', completedDate: 'November 2023' },
    { id: '8', title: 'Visit NYC', category: 'Travel', completedDate: 'October 2023' },
  ];

  const friendsData = [
    { id: '1', name: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', mutualGoals: 8 },
    { id: '2', name: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', mutualGoals: 5 },
    { id: '3', name: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', mutualGoals: 12 },
    { id: '4', name: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', mutualGoals: 3 },
    { id: '5', name: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', mutualGoals: 7 },
    { id: '6', name: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', mutualGoals: 4 },
    { id: '7', name: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', mutualGoals: 6 },
    { id: '8', name: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', mutualGoals: 9 },
    { id: '9', name: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', mutualGoals: 11 },
    { id: '10', name: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', mutualGoals: 2 },
    { id: '11', name: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', mutualGoals: 5 },
    { id: '12', name: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', mutualGoals: 8 },
    { id: '13', name: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', mutualGoals: 4 },
    { id: '14', name: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', mutualGoals: 10 },
    { id: '15', name: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', mutualGoals: 6 },
    { id: '16', name: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', mutualGoals: 3 },
    { id: '17', name: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', mutualGoals: 7 },
    { id: '18', name: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', mutualGoals: 5 },
    { id: '19', name: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', mutualGoals: 9 },
    { id: '20', name: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', mutualGoals: 4 },
    { id: '21', name: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', mutualGoals: 11 },
    { id: '22', name: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', mutualGoals: 6 },
    { id: '23', name: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', mutualGoals: 8 },
    { id: '24', name: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', mutualGoals: 3 },
  ];

  const encouragedGoalsData = [
    { id: '1', title: 'Complete a triathlon', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Health' },
    { id: '2', title: 'Learn photography', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Creative' },
    { id: '3', title: 'Visit Iceland', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Travel' },
    { id: '4', title: 'Start a podcast', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Creative' },
    { id: '5', title: 'Run a half marathon', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Health' },
    { id: '6', title: 'Learn to surf', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Adventure' },
    { id: '7', title: 'Write a book', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Creative' },
    { id: '8', title: 'Visit all 50 states', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Travel' },
    { id: '9', title: 'Master yoga', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Health' },
    { id: '10', title: 'Learn coding', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Career' },
    { id: '11', title: 'Climb Kilimanjaro', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Adventure' },
    { id: '12', title: 'Learn French', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Learning' },
    { id: '13', title: 'Start a YouTube channel', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Creative' },
    { id: '14', title: 'Run an ultramarathon', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Health' },
    { id: '15', title: 'Visit Thailand', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Travel' },
    { id: '16', title: 'Learn piano', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Creative' },
    { id: '17', title: 'Get scuba certified', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Adventure' },
    { id: '18', title: 'Read 100 books', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Learning' },
    { id: '19', title: 'Visit Greece', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Travel' },
    { id: '20', title: 'Start a blog', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Creative' },
    { id: '21', title: 'Learn Italian cooking', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Food' },
    { id: '22', title: 'Do a backpacking trip', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Adventure' },
    { id: '23', title: 'Get promoted to VP', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Career' },
    { id: '24', title: 'Learn woodworking', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Creative' },
    { id: '25', title: 'Visit New Zealand', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Travel' },
    { id: '26', title: 'Lose 30 pounds', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Health' },
    { id: '27', title: 'Learn meditation', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Wellness' },
    { id: '28', title: 'Start investing', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Finance' },
    { id: '29', title: 'Visit Japan temples', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Travel' },
    { id: '30', title: 'Build an app', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Career' },
    { id: '31', title: 'Learn dance', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Creative' },
    { id: '32', title: 'Go skydiving', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Adventure' },
    { id: '33', title: 'Master public speaking', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Career' },
    { id: '34', title: 'Visit Italy', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Travel' },
    { id: '35', title: 'Learn gardening', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Creative' },
    { id: '36', title: 'Run a 10K', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Health' },
    { id: '37', title: 'Visit Spain', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Travel' },
    { id: '38', title: 'Learn graphic design', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Creative' },
    { id: '39', title: 'Complete Ironman', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Health' },
    { id: '40', title: 'Learn German', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Learning' },
    { id: '41', title: 'Visit Morocco', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Travel' },
    { id: '42', title: 'Start side business', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Career' },
    { id: '43', title: 'Learn calligraphy', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Creative' },
    { id: '44', title: 'Go bungee jumping', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Adventure' },
    { id: '45', title: 'Visit Portugal', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Travel' },
    { id: '46', title: 'Learn chess', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Learning' },
    { id: '47', title: 'Master swimming', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Health' },
    { id: '48', title: 'Visit Australia', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Travel' },
    { id: '49', title: 'Learn violin', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Creative' },
    { id: '50', title: 'Get six-pack abs', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Health' },
    { id: '51', title: 'Visit Egypt pyramids', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Travel' },
    { id: '52', title: 'Learn web design', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Career' },
    { id: '53', title: 'Do stand-up comedy', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Creative' },
    { id: '54', title: 'Complete a century ride', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Health' },
    { id: '55', title: 'Visit Machu Picchu', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Travel' },
    { id: '56', title: 'Learn archery', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Adventure' },
    { id: '57', title: 'Get MBA', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Career' },
    { id: '58', title: 'Learn salsa dancing', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Creative' },
    { id: '59', title: 'Visit Northern Lights', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Travel' },
    { id: '60', title: 'Complete CrossFit games', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Health' },
    { id: '61', title: 'Learn to sail', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Adventure' },
    { id: '62', title: 'Write screenplay', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Creative' },
    { id: '63', title: 'Visit Bali', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Travel' },
    { id: '64', title: 'Master Excel', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Career' },
    { id: '65', title: 'Run Spartan Race', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Health' },
    { id: '66', title: 'Visit Dubai', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Travel' },
    { id: '67', title: 'Learn pottery', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Creative' },
    { id: '68', title: 'Do humanitarian work', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Social' },
    { id: '69', title: 'Visit Antarctica', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Travel' },
    { id: '70', title: 'Learn rock climbing', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Adventure' },
    { id: '71', title: 'Get published', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Creative' },
    { id: '72', title: 'Visit Switzerland', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Travel' },
    { id: '73', title: 'Master data science', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Career' },
    { id: '74', title: 'Do hot air balloon', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Adventure' },
    { id: '75', title: 'Visit Taj Mahal', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Travel' },
    { id: '76', title: 'Learn mixology', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Creative' },
    { id: '77', title: 'Complete yoga teacher training', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Health' },
    { id: '78', title: 'Visit Scotland', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Travel' },
    { id: '79', title: 'Learn film editing', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Creative' },
    { id: '80', title: 'Hike the Appalachian Trail', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Adventure' },
    { id: '81', title: 'Start nonprofit', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Career' },
    { id: '82', title: 'Visit Croatia', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Travel' },
    { id: '83', title: 'Learn boxing', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Health' },
    { id: '84', title: 'Get patent', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Career' },
    { id: '85', title: 'Visit Norway fjords', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Travel' },
    { id: '86', title: 'Learn magic tricks', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Creative' },
    { id: '87', title: 'Do 100 push-ups', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Health' },
    { id: '88', title: 'Visit Ireland', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Travel' },
    { id: '89', title: 'Learn 3D modeling', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Career' },
    { id: '90', title: 'Complete Tough Mudder', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Health' },
    { id: '91', title: 'Visit Peru', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Travel' },
    { id: '92', title: 'Learn improv', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Creative' },
    { id: '93', title: 'Adopt a pet', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Life' },
    { id: '94', title: 'Visit Amsterdam', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Travel' },
    { id: '95', title: 'Learn DJ-ing', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Creative' },
    { id: '96', title: 'Run Boston Marathon', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Health' },
    { id: '97', title: 'Visit Costa Rica', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Travel' },
    { id: '98', title: 'Master Photoshop', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Creative' },
    { id: '99', title: 'Get helicopter license', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Adventure' },
    { id: '100', title: 'Visit Vietnam', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Travel' },
    { id: '101', title: 'Learn stand-up paddleboarding', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Adventure' },
    { id: '102', title: 'Write poetry collection', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Creative' },
    { id: '103', title: 'Visit Cuba', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Travel' },
    { id: '104', title: 'Learn self-defense', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Health' },
    { id: '105', title: 'Launch online course', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Career' },
    { id: '106', title: 'Visit Brazil', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Travel' },
    { id: '107', title: 'Learn animation', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Creative' },
    { id: '108', title: 'Complete obstacle course race', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Health' },
    { id: '109', title: 'Visit Turkey', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Travel' },
    { id: '110', title: 'Get coaching certification', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Career' },
    { id: '111', title: 'Learn kitesurfing', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Adventure' },
    { id: '112', title: 'Visit Argentina', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Travel' },
    { id: '113', title: 'Master brewing beer', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Creative' },
    { id: '114', title: 'Do color run', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Health' },
    { id: '115', title: 'Visit Austria', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Travel' },
    { id: '116', title: 'Learn beat production', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Creative' },
    { id: '117', title: 'Buy first home', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Life' },
    { id: '118', title: 'Visit Poland', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Travel' },
    { id: '119', title: 'Get CPA license', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Career' },
    { id: '120', title: 'Learn paragliding', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Adventure' },
    { id: '121', title: 'Visit Finland', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Travel' },
    { id: '122', title: 'Master SEO', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Career' },
    { id: '123', title: 'Do charity marathon', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Health' },
    { id: '124', title: 'Visit Denmark', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Travel' },
    { id: '125', title: 'Learn origami', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Creative' },
    { id: '126', title: 'Complete century bike ride', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Health' },
    { id: '127', title: 'Visit Chile', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Travel' },
    { id: '128', title: 'Learn juggling', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Creative' },
    { id: '129', title: 'Start mentoring', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Career' },
    { id: '130', title: 'Visit Belgium', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Travel' },
    { id: '131', title: 'Learn hand lettering', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Creative' },
    { id: '132', title: 'Do marathon swim', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Health' },
    { id: '133', title: 'Visit Hungary', friend: 'Amanda Chen', avatar: 'https://i.pravatar.cc/150?img=13', category: 'Travel' },
    { id: '134', title: 'Get real estate license', friend: 'Kevin Patel', avatar: 'https://i.pravatar.cc/150?img=14', category: 'Career' },
    { id: '135', title: 'Learn horseback riding', friend: 'Jennifer Lopez', avatar: 'https://i.pravatar.cc/150?img=15', category: 'Adventure' },
    { id: '136', title: 'Visit Czech Republic', friend: 'Chris Brown', avatar: 'https://i.pravatar.cc/150?img=16', category: 'Travel' },
    { id: '137', title: 'Master LinkedIn', friend: 'Nicole Taylor', avatar: 'https://i.pravatar.cc/150?img=17', category: 'Career' },
    { id: '138', title: 'Do polar plunge', friend: 'Brandon White', avatar: 'https://i.pravatar.cc/150?img=18', category: 'Adventure' },
    { id: '139', title: 'Visit Singapore', friend: 'Sophia Garcia', avatar: 'https://i.pravatar.cc/150?img=19', category: 'Travel' },
    { id: '140', title: 'Learn makeup artistry', friend: 'Daniel Moore', avatar: 'https://i.pravatar.cc/150?img=20', category: 'Creative' },
    { id: '141', title: 'Get engaged', friend: 'Olivia Jackson', avatar: 'https://i.pravatar.cc/150?img=21', category: 'Life' },
    { id: '142', title: 'Visit Malaysia', friend: 'Matthew Harris', avatar: 'https://i.pravatar.cc/150?img=22', category: 'Travel' },
    { id: '143', title: 'Learn AI/ML', friend: 'Emily Clark', avatar: 'https://i.pravatar.cc/150?img=23', category: 'Career' },
    { id: '144', title: 'Do white water rafting', friend: 'Andrew Lewis', avatar: 'https://i.pravatar.cc/150?img=24', category: 'Adventure' },
    { id: '145', title: 'Visit South Korea', friend: 'Sarah Johnson', avatar: 'https://i.pravatar.cc/150?img=1', category: 'Travel' },
    { id: '146', title: 'Learn astrology', friend: 'Mike Chen', avatar: 'https://i.pravatar.cc/150?img=2', category: 'Learning' },
    { id: '147', title: 'Complete wellness retreat', friend: 'Emma Davis', avatar: 'https://i.pravatar.cc/150?img=3', category: 'Wellness' },
    { id: '148', title: 'Visit India', friend: 'Alex Thompson', avatar: 'https://i.pravatar.cc/150?img=4', category: 'Travel' },
    { id: '149', title: 'Learn sign language', friend: 'Lisa Wang', avatar: 'https://i.pravatar.cc/150?img=5', category: 'Learning' },
    { id: '150', title: 'Do charity bike ride', friend: 'James Wilson', avatar: 'https://i.pravatar.cc/150?img=6', category: 'Health' },
    { id: '151', title: 'Visit Philippines', friend: 'Rachel Green', avatar: 'https://i.pravatar.cc/150?img=7', category: 'Travel' },
    { id: '152', title: 'Master presentation skills', friend: 'Tom Anderson', avatar: 'https://i.pravatar.cc/150?img=8', category: 'Career' },
    { id: '153', title: 'Get financial freedom', friend: 'Jessica Park', avatar: 'https://i.pravatar.cc/150?img=9', category: 'Finance' },
    { id: '154', title: 'Visit Indonesia', friend: 'David Lee', avatar: 'https://i.pravatar.cc/150?img=10', category: 'Travel' },
    { id: '155', title: 'Learn ukulele', friend: 'Michelle Kim', avatar: 'https://i.pravatar.cc/150?img=11', category: 'Creative' },
    { id: '156', title: 'Complete wellness challenge', friend: 'Ryan Martinez', avatar: 'https://i.pravatar.cc/150?img=12', category: 'Health' },
  ];

  const renderStatModal = () => {
    if (!selectedStatView) return null;

    let title = '';
    let content = null;

    switch (selectedStatView) {
      case 'active':
        title = 'Active Goals';
        content = (
          <div className="space-y-3">
            {activeGoalsData.map(goal => (
              <div key={goal.id} className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-gray-900 mb-1">{goal.title}</h3>
                    <span className="inline-block px-2 py-1 rounded-full text-xs bg-indigo-100 text-indigo-700">
                      {goal.category}
                    </span>
                  </div>
                  <span className="text-indigo-600">{goal.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 h-2 rounded-full transition-all"
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        );
        break;

      case 'completed':
        title = 'Completed Goals';
        content = (
          <div className="space-y-3">
            {completedGoalsData.map(goal => (
              <div key={goal.id} className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-gray-900 mb-1">{goal.title}</h3>
                    <span className="inline-block px-2 py-1 rounded-full text-xs bg-green-100 text-green-700">
                      {goal.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    <span className="text-sm text-gray-500">{goal.completedDate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
        break;

      case 'friends':
        title = 'Friends';
        content = (
          <div className="space-y-3">
            {friendsData.map(friend => (
              <div key={friend.id} className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <img 
                    src={friend.avatar} 
                    alt={friend.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-gray-900">{friend.name}</h3>
                    <p className="text-sm text-gray-500">{friend.mutualGoals} mutual goals</p>
                  </div>
                  <button className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg text-sm hover:bg-indigo-200 transition-colors">
                    View
                  </button>
                </div>
              </div>
            ))}
          </div>
        );
        break;

      case 'encouraged':
        title = 'Goals You Encouraged';
        content = (
          <div className="space-y-3">
            {encouragedGoalsData.map(goal => (
              <div key={goal.id} className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <img 
                    src={goal.avatar} 
                    alt={goal.friend}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-gray-900 mb-1">{goal.title}</h3>
                    <p className="text-sm text-gray-500">{goal.friend}'s goal</p>
                  </div>
                  <Heart className="w-5 h-5 text-pink-500 fill-pink-500" />
                </div>
              </div>
            ))}
          </div>
        );
        break;
    }

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-gray-50 rounded-2xl max-w-2xl w-full max-h-[80vh] flex flex-col">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-white rounded-t-2xl">
            <h2 className="text-gray-900">{title}</h2>
            <button
              onClick={() => setSelectedStatView(null)}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-6">
            {content}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto px-4 py-4 md:py-8">
        {/* Header */}
        <div className="mb-6 md:mb-8">
          <h1 className="text-gray-900 mb-2">Your Feed</h1>
          <p className="text-gray-600">See what your friends are accomplishing</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6 md:mb-8">
          <div className="bg-white rounded-xl p-4 md:p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 md:w-6 md:h-6 text-indigo-600" />
              </div>
              <div>
                <p className="text-gray-600 text-xs md:text-sm">Active Goals</p>
                <p className="text-xl md:text-2xl text-gray-900">12</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedStatView('active')}
              className="mt-3 px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg text-sm hover:bg-indigo-200 transition-colors"
            >
              View
            </button>
          </div>

          <div className="bg-white rounded-xl p-4 md:p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
              </div>
              <div>
                <p className="text-gray-600 text-xs md:text-sm">Completed</p>
                <p className="text-xl md:text-2xl text-gray-900">8</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedStatView('completed')}
              className="mt-3 px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200 transition-colors"
            >
              View
            </button>
          </div>

          <div className="bg-white rounded-xl p-4 md:p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-600 text-xs md:text-sm">Friends</p>
                <p className="text-xl md:text-2xl text-gray-900">24</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedStatView('friends')}
              className="mt-3 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg text-sm hover:bg-purple-200 transition-colors"
            >
              View
            </button>
          </div>

          <div className="bg-white rounded-xl p-4 md:p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-pink-100 rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 md:w-6 md:h-6 text-pink-600" />
              </div>
              <div>
                <p className="text-gray-600 text-xs md:text-sm">Encouraged</p>
                <p className="text-xl md:text-2xl text-gray-900">156</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedStatView('encouraged')}
              className="mt-3 px-4 py-2 bg-pink-100 text-pink-700 rounded-lg text-sm hover:bg-pink-200 transition-colors"
            >
              View
            </button>
          </div>
        </div>

        {/* Feed Section */}
        <div className="mt-6 md:mt-8">
          <h2 className="text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {feedData.map(item => (
              <FeedItem
                key={item.id}
                item={item}
                onAddComment={handleAddComment}
                onToggleLike={handleToggleLike}
              />
            ))}
          </div>
        </div>
      </div>
      {renderStatModal()}
    </div>
  );
}