import { useState } from 'react';
import { Plus, CheckCircle2, Circle, Users, Calendar, Sparkles, Camera, Image as ImageIcon } from 'lucide-react';
import { AddGoalModal } from './AddGoalModal';

interface Participant {
  name: string;
  avatar: string;
}

interface BucketListGoal {
  id: string;
  title: string;
  description?: string;
  category: string;
  categoryColor: string;
  addedBy: string;
  addedDate: string;
  completedBy?: string;
  completedDate?: string;
  image?: string;
}

interface Conversation {
  id: string;
  name: string;
  type: 'individual' | 'group';
  participants: Participant[];
  activeGoals: BucketListGoal[];
  completedGoals: BucketListGoal[];
}

interface SharedBucketListViewProps {
  conversation: Conversation;
}

export function SharedBucketListView({ conversation }: SharedBucketListViewProps) {
  const [isAddGoalOpen, setIsAddGoalOpen] = useState(false);
  const [activeGoals, setActiveGoals] = useState(conversation.activeGoals);
  const [completedGoals, setCompletedGoals] = useState(conversation.completedGoals);

  const handleToggleComplete = (goalId: string, isCurrentlyActive: boolean) => {
    if (isCurrentlyActive) {
      // Move from active to completed
      const goal = activeGoals.find((g) => g.id === goalId);
      if (goal) {
        setActiveGoals(activeGoals.filter((g) => g.id !== goalId));
        setCompletedGoals([
          {
            ...goal,
            completedBy: 'You',
            completedDate: 'Just now',
          },
          ...completedGoals,
        ]);
      }
    } else {
      // Move from completed to active
      const goal = completedGoals.find((g) => g.id === goalId);
      if (goal) {
        setCompletedGoals(completedGoals.filter((g) => g.id !== goalId));
        setActiveGoals([
          ...activeGoals,
          {
            ...goal,
            completedBy: undefined,
            completedDate: undefined,
          },
        ]);
      }
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-indigo-50/30 to-purple-50/30">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="flex items-center gap-4 mb-3">
          {conversation.type === 'group' ? (
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full flex items-center justify-center">
              <Users className="w-8 h-8 text-white" />
            </div>
          ) : (
            <img
              src={conversation.participants[0].avatar}
              alt={conversation.participants[0].name}
              className="w-16 h-16 rounded-full object-cover border-2 border-gray-100"
            />
          )}
          <div>
            <h1 className="text-gray-900">{conversation.name}</h1>
            <div className="flex items-center gap-2 mt-1">
              {conversation.participants.slice(0, 3).map((p, i) => (
                <img
                  key={i}
                  src={p.avatar}
                  alt={p.name}
                  className="w-6 h-6 rounded-full object-cover border-2 border-white"
                  title={p.name}
                />
              ))}
              {conversation.participants.length > 3 && (
                <span className="text-gray-500 text-sm">
                  +{conversation.participants.length - 3} more
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsAddGoalOpen(true)}
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 px-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 hover:scale-[1.02] flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Goal to Shared List</span>
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 md:px-8 py-4 md:py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 h-full">
          {/* Active Goals */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <h2 className="text-gray-900">Active Goals</h2>
              <span className="text-gray-500">({activeGoals.length})</span>
            </div>

            {activeGoals.length === 0 ? (
              <div className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-8 text-center">
                <Circle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No active goals yet. Add one to get started!</p>
              </div>
            ) : (
              <div className="space-y-3 flex-1 overflow-y-auto pr-2">
                {activeGoals.map((goal) => (
                  <div
                    key={goal.id}
                    className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start gap-4">
                      <button
                        onClick={() => handleToggleComplete(goal.id, true)}
                        className="flex-shrink-0 mt-1 w-6 h-6 rounded-full border-2 border-gray-300 hover:border-indigo-500 hover:bg-indigo-50 transition-all"
                      >
                        <Circle className="w-full h-full text-transparent" />
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1">
                            <h3 className="text-gray-900 mb-2">{goal.title}</h3>
                            {goal.description && (
                              <p className="text-gray-600">{goal.description}</p>
                            )}
                          </div>
                          {goal.image && (
                            <img
                              src={goal.image}
                              alt={goal.title}
                              className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                            />
                          )}
                        </div>

                        <div className="flex items-center gap-3 flex-wrap">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs border ${goal.categoryColor}`}>
                            {goal.category}
                          </span>
                          <div className="flex items-center gap-1 text-gray-500 text-xs">
                            <Calendar className="w-3 h-3" />
                            <span>Added by {goal.addedBy} · {goal.addedDate}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Completed Goals */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <h2 className="text-gray-900">Completed</h2>
              <span className="text-gray-500">({completedGoals.length})</span>
            </div>

            {completedGoals.length === 0 ? (
              <div className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-8 text-center">
                <CheckCircle2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No completed goals yet. Keep working on them!</p>
              </div>
            ) : (
              <div className="space-y-3 flex-1 overflow-y-auto pr-2">
                {completedGoals.map((goal) => (
                  <div
                    key={goal.id}
                    className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start gap-4">
                      <button
                        onClick={() => handleToggleComplete(goal.id, false)}
                        className="flex-shrink-0 mt-1 w-6 h-6 rounded-full bg-green-500 border-2 border-green-500 hover:bg-green-600 transition-all flex items-center justify-center"
                      >
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-3">
                          <div className="flex-1">
                            <h3 className="text-gray-900 mb-2">{goal.title}</h3>
                            {goal.description && (
                              <p className="text-gray-600">{goal.description}</p>
                            )}
                          </div>
                          
                          {/* Photo Section */}
                          {goal.image ? (
                            <img
                              src={goal.image}
                              alt={goal.title}
                              className="w-24 h-24 rounded-lg object-cover flex-shrink-0"
                            />
                          ) : (
                            <button className="flex-shrink-0 w-24 h-24 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center bg-gray-50 hover:border-indigo-300 hover:bg-indigo-50/30 transition-all">
                              <Camera className="w-6 h-6 text-gray-400 mb-1" />
                              <span className="text-gray-400 text-xs">Add photo</span>
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-3 flex-wrap">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs border ${goal.categoryColor}`}>
                            {goal.category}
                          </span>
                          <div className="flex items-center gap-1 text-green-600 text-xs">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Completed by {goal.completedBy} · {goal.completedDate}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Goal Modal */}
      {isAddGoalOpen && <AddGoalModal onClose={() => setIsAddGoalOpen(false)} />}
    </div>
  );
}