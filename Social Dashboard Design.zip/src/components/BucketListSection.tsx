import { useState } from 'react';
import { BucketListSidebar } from './BucketListSidebar';
import { SharedBucketListView } from './SharedBucketListView';
import { bucketListFolders } from '../data/bucketListData';
import { ArrowLeft } from 'lucide-react';

export function BucketListSection() {
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(
    bucketListFolders[0]?.conversations[0]?.id || null
  );
  const [showSidebar, setShowSidebar] = useState(true);

  // Find the selected conversation across all folders
  const selectedConversation = bucketListFolders
    .flatMap(folder => folder.conversations)
    .find(c => c.id === selectedConversationId);

  const handleSelectConversation = (id: string) => {
    setSelectedConversationId(id);
    setShowSidebar(false); // Hide sidebar on mobile when selecting
  };

  const handleBackToList = () => {
    setShowSidebar(true);
  };

  return (
    <div className="h-[calc(100vh-73px)] md:h-[calc(100vh-73px)] flex overflow-hidden">
      {/* Sidebar - Hidden on mobile when conversation selected */}
      <div className={`${showSidebar ? 'block' : 'hidden'} md:block w-full md:w-auto`}>
        <BucketListSidebar
          folders={bucketListFolders}
          selectedId={selectedConversationId}
          onSelect={handleSelectConversation}
        />
      </div>

      {/* Main Content - Hidden on mobile when sidebar shown */}
      <div className={`${showSidebar ? 'hidden' : 'block'} md:block flex-1 overflow-hidden`}>
        {selectedConversation ? (
          <div className="h-full flex flex-col">
            {/* Mobile back button */}
            <button
              onClick={handleBackToList}
              className="md:hidden flex items-center gap-2 px-4 py-3 bg-white border-b border-gray-200 text-gray-700"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to lists</span>
            </button>
            <div className="flex-1 overflow-hidden">
              <SharedBucketListView 
                key={selectedConversation.id}
                conversation={selectedConversation} 
              />
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            Select a conversation to view bucket list
          </div>
        )}
      </div>
    </div>
  );
}