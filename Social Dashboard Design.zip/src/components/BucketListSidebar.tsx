import { Users, Folder, ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface Participant {
  name: string;
  avatar: string;
}

interface Conversation {
  id: string;
  name: string;
  type: 'individual' | 'group';
  participants: Participant[];
  lastActivity: string;
  activeGoalsCount: number;
  completedGoalsCount: number;
}

interface BucketListFolder {
  id: string;
  name: string;
  conversations: Conversation[];
}

interface BucketListSidebarProps {
  folders: BucketListFolder[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export function BucketListSidebar({
  folders,
  selectedId,
  onSelect,
}: BucketListSidebarProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(
    new Set(folders.map(f => f.id))
  );

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(folderId)) {
        newSet.delete(folderId);
      } else {
        newSet.add(folderId);
      }
      return newSet;
    });
  };

  const totalConversations = folders.reduce((sum, folder) => sum + folder.conversations.length, 0);

  return (
    <div className="w-full md:w-80 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-gray-50">
        <h2 className="text-gray-900">Shared Bucket Lists</h2>
        <p className="text-gray-500 text-sm mt-1">
          {totalConversations} conversation{totalConversations !== 1 ? 's' : ''}
        </p>
      </div>

      {/* Folders List */}
      <div className="flex-1 overflow-y-auto">
        {folders.map((folder) => (
          <div key={folder.id} className="border-b border-gray-100">
            {/* Folder Header */}
            <button
              onClick={() => toggleFolder(folder.id)}
              className="w-full p-3 flex items-center gap-2 hover:bg-gray-50 transition-colors bg-gray-50/50"
            >
              {expandedFolders.has(folder.id) ? (
                <ChevronDown className="w-4 h-4 text-gray-500" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-500" />
              )}
              <Folder className="w-4 h-4 text-indigo-600" />
              <span className="text-sm text-gray-900">{folder.name}</span>
              <span className="text-xs text-gray-500 ml-auto">
                {folder.conversations.length}
              </span>
            </button>

            {/* Conversations in Folder */}
            {expandedFolders.has(folder.id) && (
              <div>
                {folder.conversations.map((conversation) => (
                  <button
                    key={conversation.id}
                    onClick={() => onSelect(conversation.id)}
                    className={`w-full p-4 pl-8 flex items-start gap-3 hover:bg-gray-50 transition-colors border-b border-gray-100 ${
                      selectedId === conversation.id ? 'bg-indigo-50 border-l-4 border-l-indigo-600' : ''
                    }`}
                  >
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      {conversation.type === 'group' ? (
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-white" />
                        </div>
                      ) : (
                        <img
                          src={conversation.participants[0].avatar}
                          alt={conversation.participants[0].name}
                          className="w-12 h-12 rounded-full object-cover border-2 border-gray-100"
                        />
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 text-left min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-gray-900 truncate text-sm">{conversation.name}</h3>
                      </div>
                      <p className="text-gray-500 text-xs mb-1">
                        {conversation.activeGoalsCount} active · {conversation.completedGoalsCount} completed
                      </p>
                      <p className="text-gray-400 text-xs">{conversation.lastActivity}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
