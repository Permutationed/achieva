import { useState } from 'react';
import { X, Target, Image as ImageIcon } from 'lucide-react';

interface AddGoalModalProps {
  onClose: () => void;
}

const categories = [
  { label: 'Travel', color: 'bg-blue-100 text-blue-700 border-blue-200' },
  { label: 'Adventure', color: 'bg-orange-100 text-orange-700 border-orange-200' },
  { label: 'Learning', color: 'bg-purple-100 text-purple-700 border-purple-200' },
  { label: 'Health', color: 'bg-green-100 text-green-700 border-green-200' },
  { label: 'Career', color: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
  { label: 'Creative', color: 'bg-pink-100 text-pink-700 border-pink-200' },
  { label: 'Food & Dining', color: 'bg-red-100 text-red-700 border-red-200' },
  { label: 'Nature', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  { label: 'Social', color: 'bg-cyan-100 text-cyan-700 border-cyan-200' },
  { label: 'Skills', color: 'bg-amber-100 text-amber-700 border-amber-200' },
  { label: 'Wellness', color: 'bg-teal-100 text-teal-700 border-teal-200' },
  { label: 'Volunteering', color: 'bg-lime-100 text-lime-700 border-lime-200' },
  { label: 'Entertainment', color: 'bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200' },
  { label: 'Financial', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' },
  { label: 'Relationships', color: 'bg-rose-100 text-rose-700 border-rose-200' },
  { label: 'Personal Growth', color: 'bg-violet-100 text-violet-700 border-violet-200' },
];

export function AddGoalModal({ onClose }: AddGoalModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to the database
    console.log({ title, description, category: selectedCategory });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-gray-900">Add a New Goal</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6">
          {/* Title */}
          <div className="mb-6">
            <label htmlFor="title" className="block text-gray-700 mb-2">
              What do you want to achieve?
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Visit the Northern Lights, Learn to surf, Write a book..."
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              required
            />
          </div>

          {/* Category */}
          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Choose a category
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => setSelectedCategory(cat.label)}
                  className={`px-3 py-2 rounded-xl border-2 transition-all text-sm ${
                    selectedCategory === cat.label
                      ? cat.color + ' border-current'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <label htmlFor="description" className="block text-gray-700 mb-2">
              Add some details (optional)
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Why is this goal important to you? What steps will you take?"
              rows={4}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none"
            />
          </div>

          {/* Image Upload (Mock) */}
          <div className="mb-6">
            <label className="block text-gray-700 mb-2">
              Add inspiration photo (optional)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-indigo-400 transition-colors cursor-pointer">
              <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">Click to upload an image</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all"
            >
              Add to Bucket List
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}