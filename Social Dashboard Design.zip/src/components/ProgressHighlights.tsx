import { Target, TrendingUp } from 'lucide-react';

interface ProgressGoal {
  id: string;
  title: string;
  progress: number;
  category: string;
  color: string;
}

interface ProgressHighlightsProps {
  goals: ProgressGoal[];
}

export function ProgressHighlights({ goals }: ProgressHighlightsProps) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-6 border border-gray-100">
      <div className="flex items-center gap-2 mb-4">
        <Target className="w-5 h-5 text-indigo-600" />
        <h3 className="text-gray-900">Your Key Goals in Progress</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {goals.map(goal => (
          <div
            key={goal.id}
            className="bg-gradient-to-br from-gray-50 to-white p-4 rounded-xl border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <p className="text-gray-900 mb-1">{goal.title}</p>
                <span className={`inline-block px-2 py-1 rounded-full text-xs ${goal.color}`}>
                  {goal.category}
                </span>
              </div>
              <TrendingUp className="w-4 h-4 text-green-500 flex-shrink-0 ml-2" />
            </div>
            
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
                <span>Progress</span>
                <span>{goal.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${goal.progress}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
