export const mockProgressGoals = [
  {
    id: 'pg1',
    title: 'Learn Spanish',
    progress: 65,
    category: 'Learning',
    color: 'bg-purple-100 text-purple-700'
  },
  {
    id: 'pg2',
    title: 'Run a Half Marathon',
    progress: 40,
    category: 'Health',
    color: 'bg-green-100 text-green-700'
  },
  {
    id: 'pg3',
    title: 'Visit 10 Countries',
    progress: 80,
    category: 'Travel',
    color: 'bg-blue-100 text-blue-700'
  }
];

export const mockFeedData = [
  {
    id: 'feed1',
    user: 'Sarah Chen',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    action: 'completed' as const,
    goal: 'See the Northern Lights',
    description: 'Finally made it to Iceland and witnessed this incredible natural phenomenon! It was even more magical than I imagined. 🌌',
    image: 'https://images.unsplash.com/photo-1648607560570-4ee80c5914c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxub3J0aGVybiUyMGxpZ2h0cyUyMGF1cm9yYXxlbnwxfHx8fDE3NjYwMTYwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    timestamp: '2 hours ago',
    encouragementCount: 24,
    category: 'Travel',
    isLiked: false,
    comments: [
      {
        id: 'c1',
        user: 'Mike Johnson',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
        text: 'This is absolutely stunning! So happy for you! 🎉',
        timestamp: '1 hour ago'
      },
      {
        id: 'c2',
        user: 'Emma Davis',
        userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
        text: "This just moved up to #1 on my bucket list! Any tips?",
        timestamp: '45 minutes ago'
      }
    ]
  },
  {
    id: 'feed2',
    user: 'Alex Rodriguez',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    action: 'progress' as const,
    goal: 'Go Skydiving',
    description: 'Booked my first tandem jump for next month! Nervous but so excited. Anyone have experience with this?',
    image: 'https://images.unsplash.com/photo-1665858843828-384327053055?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza3lkaXZpbmclMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzY2MTEzMzIyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    timestamp: '5 hours ago',
    encouragementCount: 18,
    category: 'Adventure',
    isLiked: true,
    comments: [
      {
        id: 'c3',
        user: 'Lisa Park',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
        text: 'I did this last year - you\'re going to love it! The adrenaline rush is unreal!',
        timestamp: '4 hours ago'
      }
    ]
  },
  {
    id: 'feed3',
    user: 'You',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
    action: 'added' as const,
    goal: 'Learn to play guitar',
    description: 'Starting my musical journey! Got my first acoustic guitar and signed up for lessons. Time to make some music! 🎸',
    image: 'https://images.unsplash.com/photo-1758521540991-9fa804330003?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWFybmluZyUyMGd1aXRhciUyMG11c2ljfGVufDF8fHx8MTc2NjExMzMyMnww&ixlib=rb-4.1.0&q=80&w=1080',
    timestamp: '1 day ago',
    encouragementCount: 15,
    category: 'Creative',
    isLiked: false,
    comments: [
      {
        id: 'c4',
        user: 'Sarah Chen',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
        text: 'Yes! Can\'t wait to hear you play!',
        timestamp: '1 day ago'
      }
    ]
  },
  {
    id: 'feed4',
    user: 'Jordan Martinez',
    userAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
    action: 'completed' as const,
    goal: 'Complete a Marathon',
    description: 'Crossed the finish line today after 6 months of training. The mental and physical journey was incredible. Feeling proud! 🏃‍♂️',
    image: 'https://images.unsplash.com/photo-1613936360976-8f35cf0e5461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJhdGhvbiUyMHJ1bm5pbmd8ZW58MXx8fHwxNzY2MDM0MzYwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    timestamp: '2 days ago',
    encouragementCount: 42,
    category: 'Health',
    isLiked: true,
    comments: [
      {
        id: 'c5',
        user: 'Emma Davis',
        userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
        text: 'You\'re an inspiration! Congratulations! 💪',
        timestamp: '2 days ago'
      },
      {
        id: 'c6',
        user: 'Alex Rodriguez',
        userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
        text: 'Amazing achievement! How did you stay motivated?',
        timestamp: '2 days ago'
      }
    ]
  }
];
